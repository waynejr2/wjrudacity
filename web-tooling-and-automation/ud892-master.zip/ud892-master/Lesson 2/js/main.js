(function() {

	foo = 1;

})();