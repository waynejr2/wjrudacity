(function() {

	var foo = 1;
	return foo;

})();