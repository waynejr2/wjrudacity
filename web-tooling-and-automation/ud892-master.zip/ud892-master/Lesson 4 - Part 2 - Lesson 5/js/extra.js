function getWindowHeight() {
	return window.innerHeight;
}

getWindowHeight();